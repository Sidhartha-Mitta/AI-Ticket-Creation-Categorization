import {
  require_react
} from "./chunk-O5RE5CKT.js";
export default require_react();
